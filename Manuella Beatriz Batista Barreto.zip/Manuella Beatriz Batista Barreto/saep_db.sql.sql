-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Tempo de geração: 23/11/2026 às 19:23
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `clinica_vet`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `agendamentos`
--

CREATE TABLE `agendamentos` (
  `id_agendamento` int(11) NOT NULL,
  `data_agendamento` date NOT NULL,
  `hora` time NOT NULL,
  `motivo` varchar(150) NOT NULL,
  `id_pet` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `agendamentos`
--

INSERT INTO `agendamentos` (`id_agendamento`, `data_agendamento`, `hora`, `motivo`, `id_pet`, `id_usuario`) VALUES
(1, '2026-11-25', '09:00:00', 'Vacinação anual', 1, 2),
(2, '2026-11-26', '14:30:00', 'Consulta de rotina', 2, 2),
(3, '2026-11-27', '10:15:00', 'Retorno pós-cirurgia', 3, 1),
(4, '2026-11-27', '16:00:00', 'Banho e tosa', 4, 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pets`
--

CREATE TABLE `pets` (
  `id_pet` int(11) NOT NULL,
  `nome` varchar(80) NOT NULL,
  `especie` varchar(40) NOT NULL,
  `raca` varchar(60) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `id_tutor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `pets`
--

INSERT INTO `pets` (`id_pet`, `nome`, `especie`, `raca`, `data_nasc`, `id_tutor`) VALUES
(1, 'Thor', 'Cachorro', 'Labrador', '2020-03-15', 1),
(2, 'Mimi', 'Gato', 'Siamês', '2021-07-22', 2),
(3, 'Bob', 'Cachorro', 'Poodle', '2019-11-05', 3),
(4, 'Luna', 'Gato', 'Vira-lata', '2022-01-30', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tutores`
--

CREATE TABLE `tutores` (
  `id_tutor` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(255) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `endereco` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `tutores`
--

INSERT INTO `tutores` (`id_tutor`, `nome`, `cpf`, `telefone`, `email`, `endereco`) VALUES
(1, 'Maria Oliveira', 'YEUHb1bNOEaq8RaC44Ws5rguI5WH2F3LZqeveCS3Hlw=', '(81) 99999-1111', 'maria@email.com', 'Rua das Flores, 100 - Recife'),
(2, 'João Pereira', 'hpfYNkfcuXU6aq2YGmZmvMLdBSDtNCjpSyMEojQQT/s=', '(81) 98888-2222', 'joao@email.com', 'Av. Boa Viagem, 2000 - Recife'),
(3, 'Ana Santos', 'z+h0KgBqLP8e6WzH1IhwAIZStqoaeqFLv8WBKnDoPTo=', '(81) 97777-3333', 'ana@email.com', 'Rua do Sol, 45 - Olinda');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome`, `email`, `senha`) VALUES
(1, 'Administrador', 'admin@clinica.com', '$6$abcdefgh$9ehA1XIe9sCJhvBeN5h.RC6LqfRSSWtoz7EQ8yIGIjMhjV.YuAGz92H/3NCOenRyWVHeI7yYtjYttPHAVf97S0'),
(2, 'Dra. Helena Souza', 'vet@clinica.com', '$6$ijklmnop$X4sYp3lATT6i9pjN5aQ9das0YuGbODC31naQ4HYc6WyOmjTFAcRMoG8ntGkDDbSehK8xPY1uE5lVSjur6CKff.'),
(3, 'Recepção', 'recep@clinica.com', '$6$qrstuvwx$BJMS/AKOFUvVjjktnWNkhL13IpqrKVRCd157LYGU9srTP5p/NTWFBFiHNISEMn6BeSiglTE6qvAGhTdUjRAq1.');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  ADD PRIMARY KEY (`id_agendamento`),
  ADD KEY `fk_ag_pet` (`id_pet`),
  ADD KEY `fk_ag_usuario` (`id_usuario`);

--
-- Índices de tabela `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id_pet`),
  ADD KEY `fk_pet_tutor` (`id_tutor`);

--
-- Índices de tabela `tutores`
--
ALTER TABLE `tutores`
  ADD PRIMARY KEY (`id_tutor`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agendamentos`
--
ALTER TABLE `agendamentos`
  MODIFY `id_agendamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `pets`
--
ALTER TABLE `pets`
  MODIFY `id_pet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tutores`
--
ALTER TABLE `tutores`
  MODIFY `id_tutor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `agendamentos`
--
ALTER TABLE `agendamentos`
  ADD CONSTRAINT `fk_ag_pet` FOREIGN KEY (`id_pet`) REFERENCES `pets` (`id_pet`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_ag_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON UPDATE CASCADE;

--
-- Restrições para tabelas `pets`
--
ALTER TABLE `pets`
  ADD CONSTRAINT `fk_pet_tutor` FOREIGN KEY (`id_tutor`) REFERENCES `tutores` (`id_tutor`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
